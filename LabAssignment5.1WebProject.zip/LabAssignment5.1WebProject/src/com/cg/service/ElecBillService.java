package com.cg.service;

import com.cg.dto.ElectricityBill;

public interface ElecBillService 
{
	public int addBillDetails(ElectricityBill elecBill) throws Exception;
	public int generateBillNumber() throws Exception;

	
	public float calcUnitConsumed(float lMonMeterReading,float cMonMeterReading)throws Exception;
	public float calcNetAmount(float unitConsumed)throws Exception;
	public String getConsumerName(int ConsumerNumber) throws Exception;
	
	public boolean validateLMonMeterReading(float lMonMeterReading) throws Exception;
	public boolean validateCMonMeterReading(float cMonMeterReading) throws Exception;
	public boolean validateMeterReading(float lMonMeterReading,float cMonMeterReading)throws Exception;
	public boolean validateConsumerNumber(int consumerNumber) throws Exception;
}
