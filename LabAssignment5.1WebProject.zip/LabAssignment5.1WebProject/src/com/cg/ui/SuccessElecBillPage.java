package com.cg.ui;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/SuccessElecBillPage")
public class SuccessElecBillPage extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
    ServletConfig cg=null;
    HttpSession session=null;
   
    public SuccessElecBillPage() 
    {
        super();
       
    }

	
	public void init(ServletConfig config) throws ServletException 
	{
		super.init(config);
		cg=config;
	}

	
	public void destroy() 
	{
		
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException
	{
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException 
	{
		PrintWriter out=response.getWriter();
		session=request.getSession(true);
		String consName=(String)session.getAttribute("ConsumerNameObj");
		int consNo=(int)session.getAttribute("ConsumerNumberObj");
		float unitConsumed=(float)session.getAttribute("UnitConsumedObj");
		float netAmount=(float)session.getAttribute("NetAmountObj");
		out.println("<h3>Welcome "+consName+"</h3>");
		out.print("<br> <h1>Electricity Bill  for Consumer Number - "+consNo+" is </h1>");
		out.println("<br><h2>Unit Consumed :: "+unitConsumed+"</h2>");
		out.println("<br><h2>Net Amount :: "+netAmount+"</h2>");
	}

}
